import { Route, Routes } from "react-router-dom";

import "./App.css";
import React, { Suspense } from "react"
import Dashboard from "./Page/Dashboard";
import MyLeaves from "./Page/MyLeaves";
import MyTeam from "./Page/MyTeam";
import MyTask from "./Page/MyTask";
import MyProjects from "./Page/MyProjects";           
import Settings from "./Page/Settings";
import Contacts from "./Page/Contacts";
import Attendance from "./Page/Attendance";
import  Email  from "./Page/Email";
const Login = React.lazy(() => import("./Components/Global/Login/Login"));
const Loader = React.lazy(() => import("./Components/Global/Loader/Loader"));
const Navbar = React.lazy(() =>
  import("./Components/View/Employee/Navbar/Navbar")
);
const Navbar2 = React.lazy(() =>
  import("./Components/View/Admin/Navbar/Navbar2")
);
function App() {
  return (
    <>
      <Suspense fallback={<Loader />}>
        <Routes>
          <Route path="/" element={<Login />} />
            <Route path="/Admin" element={<Navbar2 />} />
            <Route path="/Employee" element={<Navbar />} />
            <Route path="/Dashboard" element={<Dashboard />} />
            <Route path="/Attendance" element={<Attendance />} />
            <Route path="/MyLeaves" element={<MyLeaves />} />
            <Route path="/MyTask" element={<MyTask />} />
            <Route path="/MyProjects" element={<MyProjects />} />
            <Route path="/MyTeam" element={<MyTeam />} />
            <Route path="/Settings" element={<Settings />} />
            <Route path="/Contacts" element={<Contacts />} />
            <Route path="/Email" element={<Email />} />
          
          </Routes>
        </Suspense>
    </>
  );
}

export default App;


