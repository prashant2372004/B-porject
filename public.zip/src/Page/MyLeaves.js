import * as React from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MailIcon from '@mui/icons-material/Mail';
import Dropdown from 'react-bootstrap/Dropdown';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import ScheduleIcon from '@mui/icons-material/Schedule';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import LunchDiningIcon from '@mui/icons-material/LunchDining';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import ComputerIcon from '@mui/icons-material/Computer';
import EditNoteIcon from '@mui/icons-material/EditNote';
import DescriptionIcon from '@mui/icons-material/Description';

import PeopleAltIcon from '@mui/icons-material/PeopleAlt';
import PieChartIcon from '@mui/icons-material/PieChart';
import TaskIcon from '@mui/icons-material/Task';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import { Link } from "react-router-dom";   
import "./App2.css"                                                                               


import "./Dashboard"

const drawerWidth = 240;


const MyLeaves = () => {                                                                                                                            
  // Navbar//
  const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
  });

  const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
      width: `calc(${theme.spacing(8)} + 1px)`,
    },
  });

  const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
  }));

  const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
  })(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    }),
  }));

  const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
      width: drawerWidth,
      flexShrink: 0,
      whiteSpace: 'nowrap',
      boxSizing: 'border-box',
      ...(open && {
        ...openedMixin(theme),
        '& .MuiDrawer-paper': openedMixin(theme),
      }),
      ...(!open && {
        ...closedMixin(theme),
        '& .MuiDrawer-paper': closedMixin(theme),
      }),
    }),
  );

  const theme = useTheme();

  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  // slider menu

  const [close, setClose] = React.useState(false);

  const handleClick = () => {
    setClose(!close);
  };


  return (
    <div>

      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar position="fixed" open={open} style={{ background: '#1B212E' }}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={handleDrawerOpen}
              edge="start"
              sx={{
                marginRight: 5,
                ...(open && { display: 'none' }),
              }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" noWrap component="div">
              <h4>  Admin  </h4>
            </Typography>
            <div class="d-flex ms-auto">

              <Dropdown>
                <Dropdown.Toggle style={{ background: '#1B212E', border: 'none', boxShadow: 'none' }}>
                  <NotificationsNoneIcon />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1"><MailIcon style={{ color: '#50CD75' }} /> Please check your mail <br /> <span className='text-muted ms-5 fw-lighter fs-6'><ScheduleIcon className='fs-6' />14 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><PersonAddIcon style={{ color: '#5D79FF' }} /> New Employee added.. <br /> <span className='text-muted ms-5 fw-lighter'>22 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><CalendarMonthIcon style={{ color: '#FFC106' }} /> Your leave is approved!! <br /> <span className='text-muted ms-5 fw-lighter'>3 hours ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><LunchDiningIcon style={{ color: '#5D79FF' }} /> Lets break for lunch... <br /> <span className='text-muted ms-5 fw-lighter'>5 hours ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><InsertDriveFileIcon style={{ color: '#50CD75' }} /> Employee report generated <br /> <span className='text-muted ms-5 fw-lighter'>14 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><MailIcon style={{ color: '#FF150D' }} /> Please check your mail <br /> <span className='text-muted ms-5 fw-lighter'>22 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><MonetizationOnIcon style={{ color: '#C000FF' }} /> Salary credited... <br /> <span className='text-muted ms-5 fw-lighter'>3 hours ago</span></Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              <Dropdown>
                <Dropdown.Toggle style={{ background: '#1B212E', border: 'none', boxShadow: 'none' }}>
                  <span className='me-2'>Ashton Cox</span>
                  <img
                    src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp"
                    class="rounded-circle"
                    height="25"
                    alt="Black"
                    loading="lazy"
                  />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1"><PermIdentityIcon /> Account</Dropdown.Item>
                  <Dropdown.Item href="#/action-2"><MailOutlineIcon /> Inbox</Dropdown.Item>
                  <Dropdown.Item href="#/action-3"><SettingsIcon /> Settings</Dropdown.Item>
                  <Dropdown.Item href="#/action-3"><LogoutIcon /> Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>

          </Toolbar>
        </AppBar>

        <Drawer variant="permanent" open={open}>
          <DrawerHeader style={{background:'#1A202E'}}>
            <IconButton onClick={handleDrawerClose} style={{color:'white'}}>
              {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
            </IconButton>
          </DrawerHeader>

          {/* Silder manu */}

          <List
            style={{width: '100%', maxWidth: 360, background:'#1A202E'}}
            component="nav"
            aria-labelledby="nested-list-subheader"
          >

          <img src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp" class="rounded mx-auto d-block w-25 shadow-lg bg-body-tertiary rounded" alt="#" />
          <h6 className='text-bolder text-white text-center mt-2'>Ashton Cox <br /> <span className='text-white text-center text-muted'>main</span></h6>

            <h6 className='ms-1 text-white'>Main</h6>

            <ListItemButton >
              <ListItemIcon>
                <ComputerIcon  className='text-white'/>
              </ListItemIcon>
              <Link to={"/Dashboard"}> <ListItemText primary="Dashboard"   className='text-white'/></Link>
   
            
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <EditNoteIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Attendance"}> <ListItemText primary="Attendance"  className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <DescriptionIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyLeaves"}>  <ListItemText primary="MyLeaves" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <PeopleAltIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyTeam"}> <ListItemText primary="MyTeam" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <PieChartIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyProjects"}>  <ListItemText primary="MyProjects" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <TaskIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyTask"}> <ListItemText primary="MyTask" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <SettingsIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Settings"}>   <ListItemText primary="Settings" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <GroupAddIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Contacts"}>  <ListItemText primary="Contacts" className='text-white'/></Link>
            </ListItemButton>


            <ListItemButton onClick={handleClick} className='text-white'>
              <ListItemIcon>
                <DescriptionIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Email"}>    <ListItemText primary="Email" className='text-white'/></Link>

            </ListItemButton>
           

                <ListItemButton>
                  <ListItemIcon>
                    <LogoutIcon className='text-white'/>
                  </ListItemIcon>
                  <Link to={"/"}>   <ListItemText primary="Logout" className='text-white'/></Link>
                </ListItemButton>
          </List>
        </Drawer>


       
        <Box className='  text-white  '  component="main" sx={{ flexGrow: 1, p: 3 }}>
          <DrawerHeader />
 <><div className="container-fluid">
    <div className="row">
      <div className="col-md-12">
        <div className="container-fluid ps-3">
          <div className="row">
            <div className="col-md-4">
              <h1>Leaves</h1>
              <p>
                {" "}
                <strong>Dashboard </strong>/ Leaves
              </p>
            </div>
            <div className="col-md-4"></div>
            <div className="col-md-4 p-3">
              {/* Button trigger modal */}
              <a href="#">
                <button
                  type="button"
                  data-bs-toggle="modal"
                  data-bs-target="#staticBackdrop"
                  className="btn float-end rounded-5  text-white fw-bolder"
                  style={{ backgroundColor: "#FF9B44" }}
                >
                  <i className="bi bi-plus fw-bolder" /> Add Employee
                </button>
              </a>
              {/* Modal */}
              {/* Modal */}
              <div
                className="modal fade"
                id="staticBackdrop"
                data-bs-backdrop="static"
                data-bs-keyboard="false"
                tabIndex={-1}
                aria-labelledby="staticBackdropLabel"
                aria-hidden="true"
              >
                <div className="modal-dialog">
                  <div className="modal-content">
                    <div className="modal-header">
                      <button
                        type="button"
                        className="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      />
                    </div>
                    {/* form */}
                    <h3 className="text-center mt-5">Add Leave</h3>
                    <form action="" className="cal mt-5">
                      <div
                        className="row  justify-content-center needs-validation"
                        noValidate=""
                      >
                        <div className="col-md-10">
                          <label
                            htmlFor="validationCustom02"
                            className="form-label"
                          >
                            Last name
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom02"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                      <br />
                      <div
                        className="row  justify-content-center needs-validation"
                        noValidate=""
                      >
                        <div className="col-md-10">
                          <label
                            htmlFor="validationCustom02"
                            className="form-label"
                          >
                            Email <span className="text-danger">*</span>
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom02"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                      <br />
                      <div
                        className="row  justify-content-center needs-validation"
                        noValidate=""
                      >
                        <div className="col-md-10">
                          <label
                            htmlFor="validationCustom02"
                            className="form-label"
                          >
                            Confirm Password
                          </label>
                          <input
                            type="text"
                            className="form-control"
                            id="validationCustom02"
                            defaultValue=""
                            required=""
                          />
                        </div>
                      </div>
                      <br />
                      <div
                        className="row  justify-content-center needs-validation"
                        noValidate=""
                      >
                        <div className="col-md-10">
                          <label
                            htmlFor="validationCustom02"
                            className="form-label"
                          >
                            Joining Date <span className="text-danger">*</span>
                          </label>
                          <input
                            type="date"
                            id="birthday"
                            className="form-control"
                            required=""
                          />
                        </div>
                      </div>
                      <br />
                      <div
                        className="row  justify-content-center needs-validation"
                        noValidate=""
                      >
                        <div className="col-md-10">
                          <label
                            htmlFor="validationCustom02"
                            className="form-label"
                          >
                            Company
                          </label>
                          <div className="form-group">
                            <select className="form-control">
                              <option>Vision Infotech</option>
                              <option>Riseup Infotech </option>
                              <option>Techxx Infotech</option>
                              <option>New Era Tecnosoft</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <br />
                      <div
                        className="row  justify-content-center needs-validation"
                        noValidate=""
                      >
                        <div className="col-md-10">
                          <label
                            htmlFor="validationCustom01"
                            className="form-label"
                          >
                            Designation <span className="text-danger">*</span>
                          </label>
                          <div className="form-group">
                            <select className="form-control" id="dd">
                              <option>Select Designation</option>
                              <option>Web Designer</option>
                              <option>Android Designer</option>
                              <option>Web Developer</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div className="col-12 mt-3 mb-5 d-flex">
                        <button
                          className="btn  rounded-pill fs-5"
                          type="submit"
                          style={{ backgroundColor: "#FF9B44" }}
                        >
                          {" "}
                          Submit{" "}
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid ps-5 d-sm-none d-none d-lg-flex ">
          <div className="col-3 bg-secondary   bg-opacity-25">
            {" "}
            <h6 className="ps-4 pt-2">Today Presents</h6>
            <p className="ps-4">
              {" "}
              <strong className="ps-4 ">12 / 60 </strong>
            </p>
          </div>
          <div className="col-2 bg-secondary  bg-opacity-25  ms-4">
            <h6 className=" ps-4 pt-2">Planned Leave</h6>
            <p className=" ms-4">
              {" "}
              <strong className="ps-4 ">8 Today </strong>
            </p>
          </div>
          <div className="col-3 bg-secondary   bg-opacity-25 ms-4">
            <h6 className="ps-5 pt-2 ">Unplanned Leaves</h6>
            <p className="ms-5">
              {" "}
              <strong className="ps-4 ">0 Today </strong>
            </p>
          </div>
          <div className="col-3 bg-secondary   bg-opacity-25 ms-4">
            <h6 className="ps-5 pt-2 ">Pending Requests</h6>
            <p className="ps-4 ms-5  ">
              {" "}
              <strong className="ps-4 ">12 </strong>
            </p>
          </div>
        </div>
        {/* navbar */}
        <div
          className="row  w-100 ms-1 needs-validation ms-5 mb-2"
          noValidate=""
        >
          <div className="col-md-2 mt-3">
            <input
              type="text"
              className="form-control p-3"
              id="validationCustom01"
              placeholder="Employee ID"
            />
          </div>
          <div className="col-md-2 mt-3">
            <input
              type="text"
              className="form-control p-3"
              id="validationCustom02"
              placeholder="Employee Name"
            />
          </div>
          <div className="col-md-2 mt-3">
            <input
              type="text"
              className="form-control p-3"
              id="validationCustom01"
              placeholder="Employee ID"
            />
          </div>
          <div className="form-group col-md-3 mt-3">
            <select className="form-control p-3 " id="dd">
              <option>Select Designation</option>
              <option>Web Designer</option>
              <option>Android Designer</option>
              <option>Web Developer</option>
            </select>
          </div>
          <div className="col-md-2 mt-3 pe-4">
            <button className="button w-100 p-3 rounded-1 "> SEARCH </button>
          </div>
        </div>
        <div className="list">
          <div className="container-fluid  ">
            <div className="row ">
              <div className="col-md-12   ">
                <div className="row p-2 d-sm-none d-none d-lg-flex">
                  <div className="col-2">
                    {" "}
                    <strong>Employee</strong>
                  </div>
                  <div className="col-2">
                    {" "}
                    <i className="fa-solid fa-arrow-up text-secondary" />
                    <i className="fa-solid fa-arrow-down text-secondary" />{" "}
                    <strong>Leave Type </strong>
                  </div>
                  <div className="col-2">
                    {" "}
                    <i className="fa-solid fa-arrow-up text-secondary" />
                    <i className="fa-solid fa-arrow-down text-secondary" />
                    <strong>From</strong>
                  </div>
                  <div className="col-2">
                    {" "}
                    <i className="fa-solid fa-arrow-up text-secondary" />
                    <i className="fa-solid fa-arrow-down text-secondary" />{" "}
                    <strong>TO</strong>
                  </div>
                  <div className="col-2">
                    {" "}
                    <i className="fa-solid fa-arrow-up text-secondary" />
                    <i className="fa-solid fa-arrow-down text-secondary" />{" "}
                    <strong>No of Days </strong>
                  </div>
                  <div className="col-2">
                    {" "}
                    <i className="fa-solid fa-arrow-up text-secondary" />
                    <i className="fa-solid fa-arrow-down text-secondary" />{" "}
                    <strong>Reason </strong>
                  </div>
                </div>
               
                
                <div className="item">
                  <div>
                    <div className="flow-root">
                      <ul
                        role="list"
                        className="divide-y divide-gray-200 dark:divide-gray-700"
                      >
                        <li className="py-3 sm:py-4">
                          <div className="flex items-center space-x-4">
                            <div className="flex-shrink-0">
                              <img
                                className="w-8 h-8 rounded-full"
                                src="https://picsum.photos/200"
                                alt="Thomas image"
                              />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-gray-900 truncate dark:text-white">
                                Michael Gough
                              </p>
                              <p className="text-sm text-gray-500 truncate dark:text-gray-400">
                                email@windster.com
                              </p>
                            </div>
                            <div className="inline-flex items-center text-base font-semibold text-gray-900 dark:text-white">
                              $67
                            </div>
                            <div className="inline-flex items-center text-base  font-semibold text-gray-900 dark:text-white"></div>
                            <div className="inline-flex items-center text-base  font-semibold text-gray-900 dark:text-white"></div>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <ul className="listPage"></ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div></>
        </Box>
      </Box>
    </div>
  )
}



export default MyLeaves
