import * as React from 'react';
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MailIcon from '@mui/icons-material/Mail';
import Dropdown from 'react-bootstrap/Dropdown';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import ScheduleIcon from '@mui/icons-material/Schedule';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import LunchDiningIcon from '@mui/icons-material/LunchDining';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import ComputerIcon from '@mui/icons-material/Computer';
import EditNoteIcon from '@mui/icons-material/EditNote';
import DescriptionIcon from '@mui/icons-material/Description';

import PeopleAltIcon from '@mui/icons-material/PeopleAlt';
import PieChartIcon from '@mui/icons-material/PieChart';
import TaskIcon from '@mui/icons-material/Task';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import { Link } from "react-router-dom";                                                                                  


import "./Dashboard"

const drawerWidth = 240;


const Contacts = () => {                                                                                                                            
  // Navbar//
  const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
  });

  const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
      width: `calc(${theme.spacing(8)} + 1px)`,
    },
  });

  const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
  }));

  const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
  })(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    }),
  }));

  const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
      width: drawerWidth,
      flexShrink: 0,
      whiteSpace: 'nowrap',
      boxSizing: 'border-box',
      ...(open && {
        ...openedMixin(theme),
        '& .MuiDrawer-paper': openedMixin(theme),
      }),
      ...(!open && {
        ...closedMixin(theme),
        '& .MuiDrawer-paper': closedMixin(theme),
      }),
    }),
  );

  const theme = useTheme();

  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  // slider menu

  const [close, setClose] = React.useState(false);

  const handleClick = () => {
    setClose(!close);
  };


  return (
    <div>

      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar position="fixed" open={open} style={{ background: '#1B212E' }}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={handleDrawerOpen}
              edge="start"
              sx={{
                marginRight: 5,
                ...(open && { display: 'none' }),
              }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" noWrap component="div">
              <h4>  Admin  </h4>
            </Typography>
            <div class="d-flex ms-auto">

              <Dropdown>
                <Dropdown.Toggle style={{ background: '#1B212E', border: 'none', boxShadow: 'none' }}>
                  <NotificationsNoneIcon />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1"><MailIcon style={{ color: '#50CD75' }} /> Please check your mail <br /> <span className='text-muted ms-5 fw-lighter fs-6'><ScheduleIcon className='fs-6' />14 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><PersonAddIcon style={{ color: '#5D79FF' }} /> New Employee added.. <br /> <span className='text-muted ms-5 fw-lighter'>22 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><CalendarMonthIcon style={{ color: '#FFC106' }} /> Your leave is approved!! <br /> <span className='text-muted ms-5 fw-lighter'>3 hours ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><LunchDiningIcon style={{ color: '#5D79FF' }} /> Lets break for lunch... <br /> <span className='text-muted ms-5 fw-lighter'>5 hours ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><InsertDriveFileIcon style={{ color: '#50CD75' }} /> Employee report generated <br /> <span className='text-muted ms-5 fw-lighter'>14 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><MailIcon style={{ color: '#FF150D' }} /> Please check your mail <br /> <span className='text-muted ms-5 fw-lighter'>22 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><MonetizationOnIcon style={{ color: '#C000FF' }} /> Salary credited... <br /> <span className='text-muted ms-5 fw-lighter'>3 hours ago</span></Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              <Dropdown>
                <Dropdown.Toggle style={{ background: '#1B212E', border: 'none', boxShadow: 'none' }}>
                  <span className='me-2'>Ashton Cox</span>
                  <img
                    src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp"
                    class="rounded-circle"
                    height="25"
                    alt="Black"
                    loading="lazy"
                  />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1"><PermIdentityIcon /> Account</Dropdown.Item>
                  <Dropdown.Item href="#/action-2"><MailOutlineIcon /> Inbox</Dropdown.Item>
                  <Dropdown.Item href="#/action-3"><SettingsIcon /> Settings</Dropdown.Item>
                  <Dropdown.Item href="#/action-3"><LogoutIcon /> Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>

          </Toolbar>
        </AppBar>

        <Drawer variant="permanent" open={open}>
          <DrawerHeader style={{background:'#1A202E'}}>
            <IconButton onClick={handleDrawerClose} style={{color:'white'}}>
              {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
            </IconButton>
          </DrawerHeader>

          {/* Silder manu */}

          <List
            style={{width: '100%', maxWidth: 360, background:'#1A202E'}}
            component="nav"
            aria-labelledby="nested-list-subheader"
          >

          <img src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp" class="rounded mx-auto d-block w-25 shadow-lg bg-body-tertiary rounded" alt="#" />
          <h6 className='text-bolder text-white text-center mt-2'>Ashton Cox <br /> <span className='text-white text-center text-muted'>main</span></h6>

            <h6 className='ms-1 text-white'>Main</h6>

            <ListItemButton >
              <ListItemIcon>
                <ComputerIcon  className='text-white'/>
              </ListItemIcon>
              <Link to={"/Dashboard"}> <ListItemText primary="Dashboard"   className='text-white'/></Link>
   
            
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <EditNoteIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Attendance"}> <ListItemText primary="Attendance"  className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <DescriptionIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyLeaves"}>  <ListItemText primary="MyLeaves" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <PeopleAltIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyTeam"}> <ListItemText primary="MyTeam" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <PieChartIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyProjects"}>  <ListItemText primary="MyProjects" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <TaskIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyTask"}> <ListItemText primary="MyTask" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <SettingsIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Settings"}>   <ListItemText primary="Settings" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <GroupAddIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Contacts"}>  <ListItemText primary="Contacts" className='text-white'/></Link>
            </ListItemButton>


            <ListItemButton onClick={handleClick} className='text-white'>
              <ListItemIcon>
                <DescriptionIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Email"}>    <ListItemText primary="Email" className='text-white'/></Link>

            </ListItemButton>
           

                <ListItemButton>
                  <ListItemIcon>
                    <LogoutIcon className='text-white'/>
                  </ListItemIcon>
                  <Link to={"/"}>   <ListItemText primary="Logout" className='text-white'/></Link>
                </ListItemButton>
          </List>
        </Drawer>


       
        <Box className='  text-white  ' component="main" sx={{ flexGrow: 1, p: 3 }}>
          <DrawerHeader />
          contacte
        </Box>
      </Box>

    </div>
  )
}



export default Contacts
