import * as React from 'react';
import  Apps  from './Apps.js';                                  
import { styled, useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MuiDrawer from '@mui/material/Drawer';
import MuiAppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import CssBaseline from '@mui/material/CssBaseline';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MailIcon from '@mui/icons-material/Mail';
import Dropdown from 'react-bootstrap/Dropdown';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import ScheduleIcon from '@mui/icons-material/Schedule';
import PersonAddIcon from '@mui/icons-material/PersonAdd';
import CalendarMonthIcon from '@mui/icons-material/CalendarMonth';
import LunchDiningIcon from '@mui/icons-material/LunchDining';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import ComputerIcon from '@mui/icons-material/Computer';
import EditNoteIcon from '@mui/icons-material/EditNote';
import DescriptionIcon from '@mui/icons-material/Description';

import PeopleAltIcon from '@mui/icons-material/PeopleAlt';
import PieChartIcon from '@mui/icons-material/PieChart';
import TaskIcon from '@mui/icons-material/Task';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import { Link } from "react-router-dom"; 



import "../Page/Dashboard"

const drawerWidth = 240;


const Dashboard = () => {                                                                                                                            
  // Navbar//

  var divStyle = {

    paddingLeft:"1034px",
  
  };
  const openedMixin = (theme) => ({
    width: drawerWidth,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    overflowX: 'hidden',
  });

  const closedMixin = (theme) => ({
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    width: `calc(${theme.spacing(7)} + 1px)`,
    [theme.breakpoints.up('sm')]: {
      width: `calc(${theme.spacing(8)} + 1px)`,
    },
  });

  const DrawerHeader = styled('div')(({ theme }) => ({
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end',
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
  }));

  const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== 'open',
  })(({ theme, open }) => ({
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(['width', 'margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
      marginLeft: drawerWidth,
      width: `calc(100% - ${drawerWidth}px)`,
      transition: theme.transitions.create(['width', 'margin'], {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.enteringScreen,
      }),
    }),
  }));

  const Drawer = styled(MuiDrawer, { shouldForwardProp: (prop) => prop !== 'open' })(
    ({ theme, open }) => ({
      width: drawerWidth,
      flexShrink: 0,
      whiteSpace: 'nowrap',
      boxSizing: 'border-box',
      ...(open && {
        ...openedMixin(theme),
        '& .MuiDrawer-paper': openedMixin(theme),
      }),
      ...(!open && {
        ...closedMixin(theme),
        '& .MuiDrawer-paper': closedMixin(theme),
      }),
    }),
  );

  const theme = useTheme();

  const [open, setOpen] = React.useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  // slider menu

  const [close, setClose] = React.useState(false);

  const handleClick = () => {
    setClose(!close);
  };


  return (
    <div>

      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar position="fixed" open={open} style={{ background: '#1B212E' }}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={handleDrawerOpen}
              edge="start"
              sx={{
                marginRight: 5,
                ...(open && { display: 'none' }),
              }}
            >
              <MenuIcon />
            </IconButton>
            <Typography variant="h6" noWrap component="div">
              <h4>  Admin  </h4>
            </Typography>
            <div class="d-flex ms-auto">

              <Dropdown>
                <Dropdown.Toggle style={{ background: '#1B212E', border: 'none', boxShadow: 'none' }}>
                  <NotificationsNoneIcon />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1"><MailIcon style={{ color: '#50CD75' }} /> Please check your mail <br /> <span className='text-muted ms-5 fw-lighter fs-6'><ScheduleIcon className='fs-6' />14 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><PersonAddIcon style={{ color: '#5D79FF' }} /> New Employee added.. <br /> <span className='text-muted ms-5 fw-lighter'>22 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><CalendarMonthIcon style={{ color: '#FFC106' }} /> Your leave is approved!! <br /> <span className='text-muted ms-5 fw-lighter'>3 hours ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><LunchDiningIcon style={{ color: '#5D79FF' }} /> Lets break for lunch... <br /> <span className='text-muted ms-5 fw-lighter'>5 hours ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><InsertDriveFileIcon style={{ color: '#50CD75' }} /> Employee report generated <br /> <span className='text-muted ms-5 fw-lighter'>14 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><MailIcon style={{ color: '#FF150D' }} /> Please check your mail <br /> <span className='text-muted ms-5 fw-lighter'>22 mins ago</span></Dropdown.Item>
                  <Dropdown.Item href="#/action-1"><MonetizationOnIcon style={{ color: '#C000FF' }} /> Salary credited... <br /> <span className='text-muted ms-5 fw-lighter'>3 hours ago</span></Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
              <Dropdown>
                <Dropdown.Toggle style={{ background: '#1B212E', border: 'none', boxShadow: 'none' }}>
                  <span className='me-2'>Ashton Cox</span>
                  <img
                    src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp"
                    class="rounded-circle"
                    height="25"
                    alt="Black"
                    loading="lazy"
                  />
                </Dropdown.Toggle>

                <Dropdown.Menu>
                  <Dropdown.Item href="#/action-1"><PermIdentityIcon /> Account</Dropdown.Item>
                  <Dropdown.Item href="#/action-2"><MailOutlineIcon /> Inbox</Dropdown.Item>
                  <Dropdown.Item href="#/action-3"><SettingsIcon /> Settings</Dropdown.Item>
                  <Dropdown.Item href="#/action-3"><LogoutIcon /> Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>
            </div>

          </Toolbar>
        </AppBar>

        <Drawer variant="permanent" open={open}>
          <DrawerHeader style={{background:'#1A202E'}}>
            <IconButton onClick={handleDrawerClose} style={{color:'white'}}>
              {theme.direction === 'rtl' ? <ChevronRightIcon /> : <ChevronLeftIcon />}
            </IconButton>
          </DrawerHeader>

          {/* Silder manu */}

          <List
            style={{width: '100%', maxWidth: 360, background:'#1A202E'}}
            component="nav"
            aria-labelledby="nested-list-subheader"
          >

          <img src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp" class="rounded mx-auto d-block w-25 shadow-lg bg-body-tertiary rounded" alt="#" />
          <h6 className='text-bolder text-white text-center mt-2'>Ashton Cox <br /> <span className='text-white text-center text-muted'>main</span></h6>

            <h6 className='ms-1 text-white'>Main</h6>
            
            <ListItemButton >
              <ListItemIcon>
                <ComputerIcon  className='text-white'/>
              </ListItemIcon>
              <Link to={"/Dashboard"}> <ListItemText primary="Dashboard"   className='text-white'/></Link>
   
            
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <EditNoteIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Attendance"}> <ListItemText primary="Attendance"  className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <DescriptionIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyLeaves"}>  <ListItemText primary="MyLeaves" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <PeopleAltIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyTeam"}> <ListItemText primary="MyTeam" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <PieChartIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyProjects"}>  <ListItemText primary="MyProjects" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <TaskIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/MyTask"}> <ListItemText primary="MyTask" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <SettingsIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Settings"}>   <ListItemText primary="Settings" className='text-white'/></Link>
            </ListItemButton>

            <ListItemButton>
              <ListItemIcon>
                <GroupAddIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Contacts"}>  <ListItemText primary="Contacts" className='text-white'/></Link>
            </ListItemButton>


            <ListItemButton onClick={handleClick} className='text-white'>
              <ListItemIcon>
                <DescriptionIcon className='text-white'/>
              </ListItemIcon>
              <Link to={"/Email"}>    <ListItemText primary="Email" className='text-white'/></Link>

            </ListItemButton>
           

                <ListItemButton>
                  <ListItemIcon>
                    <LogoutIcon className='text-white'/>
                  </ListItemIcon>
                  <Link to={"/"}>   <ListItemText primary="Logout" className='text-white'/></Link>
                </ListItemButton>
          </List>
        </Drawer>

       
        <Box className='  text-white  '  component="main" sx={{ flexGrow: 1, p: 3 }}  >
          <DrawerHeader />


          <div class="container-fluid ps-5 mx-auto">
	<div class="row mx-auto pt-4 pb-4 ps-5" >
  
	{/* <div class="col-md-12  ps-5 "  style={divStyle} > */}
                 <Apps />
		{/* </div> */}
	</div>
</div>
    
          <>
          <div className="row">
            <div className="col-md-6 col-xl-4">
              <div className="card mb-3 widget-content">
                <div className="widget-content-outer">
                  <div className="widget-content-wrapper">
                    <div className="widget-content-left">
                      <div className="widget-heading text-dark">Total Orders</div>
                      <div className="widget-subheading text-dark">
                        Last year expenses  
                      </div>
                    </div>
                    <div className="widget-content-right">
                      <div className="widget-numbers text-success">1896</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-xl-4">
              <div className="card mb-3 widget-content">
                <div className="widget-content-outer">
                  <div className="widget-content-wrapper">
                    <div className="widget-content-left">
                      <div className="widget-heading text-dark">Products Sold</div>
                      <div className="widget-subheading text-dark">Revenue streams</div>
                    </div>
                    <div className="widget-content-right">
                      <div className="widget-numbers text-warning ">$3M</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-xl-4">
              <div className="card mb-3 widget-content">
                <div className="widget-content-outer">
                  <div className="widget-content-wrapper">
                    <div className="widget-content-left">
                      <div className="widget-heading text-dark">Followers</div>
                      <div className="widget-subheading text-dark">People Interested</div>
                    </div>
                    <div className="widget-content-right">
                      <div className="widget-numbers text-danger text-dark">45,9%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="d-xl-none d-lg-block col-md-6 col-xl-4">
              <div className="card mb-3 widget-content">
                <div className="widget-content-outer">
                  <div className="widget-content-wrapper">
                    <div className="widget-content-left">
                      <div className="widget-heading">Income</div>
                      <div className="widget-subheading">Expected totals</div>
                    </div>
                    <div className="widget-content-right">
                      <div className="widget-numbers text-focus">$147</div>
                    </div>
                  </div>
                  <div className="widget-progress-wrapper">
                    <div className="progress-bar-sm progress-bar-animated-alt progress">
                      <div
                        className="progress-bar bg-info"
                        role="progressbar"
                        aria-valuenow={54}
                        aria-valuemin={0}
                        aria-valuemax={100}
                        style={{ width: "54%" }}
                      />
                    </div>
                    <div className="progress-sub-label">
                      <div className="sub-label-left">Expenses</div>
                      <div className="sub-label-right">100%</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-12">
              <div className="main-card mb-3 card">
                <div className="card-header text-dark">
                  Active Users
                  <div className="btn-actions-pane-right">
                    <div role="group" className="btn-group-sm btn-group">
                      <button className="active btn btn-focus text-dark">
                        Last Week
                      </button>
                      <button className="btn btn-focus text-dark">All Month</button>
                    </div>
                  </div>
                </div>
                <div className="table-responsive">
                  <table className="align-middle mb-0 table table-borderless table-striped table-hover">
                    <thead>
                      <tr>
                        <th className="text-center">#</th>
                        <th>Name</th>
                        <th className="text-center">City</th>
                        <th className="text-center">Status</th>
                        <th className="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="text-center text-muted">#345</td>
                        <td>
                          <div className="widget-content p-0">
                            <div className="widget-content-wrapper">
                              <div className="widget-content-left mr-3">
                                <div className="widget-content-left">
                                  <img
                                    width={40}
                                    className="rounded-circle"
                                    src="assets/images/avatars/4.jpg"
                                    alt=""
                                  />
                                </div>
                              </div>
                              <div className="widget-content-left flex2">
                                <div className="widget-heading">John Doe</div>
                                <div className="widget-subheading opacity-7">
                                  Web Developer
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="text-center">Madrid</td>
                        <td className="text-center">
                          <div className="badge badge-warning text-dark">Pending</div>
                        </td>
                        <td className="text-center">
                          <button
                            type="button"
                            id="PopoverCustomT-1"
                            className="btn btn-primary btn-sm "
                          >
                            Details
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td className="text-center text-muted">#347</td>
                        <td>
                          <div className="widget-content p-0">
                            <div className="widget-content-wrapper">
                              <div className="widget-content-left mr-3">
                                <div className="widget-content-left">
                                  <img
                                    width={40}
                                    className="rounded-circle"
                                    src="assets/images/avatars/3.jpg"
                                    alt=""
                                  />
                                </div>
                              </div>
                              <div className="widget-content-left flex2">
                                <div className="widget-heading">
                                  Ruben Tillman
                                </div>
                                <div className="widget-subheading opacity-7">
                                  Etiam sit amet orci eget
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="text-center">Berlin</td>
                        <td className="text-center">
                          <div className="badge badge-success text-dark">Completed</div>
                        </td>
                        <td className="text-center">
                          <button
                            type="button"
                            id="PopoverCustomT-2"
                            className="btn btn-primary btn-sm"
                          >
                            Details
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td className="text-center text-muted">#321</td>
                        <td>
                          <div className="widget-content p-0">
                            <div className="widget-content-wrapper">
                              <div className="widget-content-left mr-3">
                                <div className="widget-content-left">
                                  <img
                                    width={40}
                                    className="rounded-circle"
                                    src="assets/images/avatars/2.jpg"
                                    alt=""
                                  />
                                </div>
                              </div>
                              <div className="widget-content-left flex2">
                                <div className="widget-heading">
                                  Elliot Huber
                                </div>
                                <div className="widget-subheading opacity-7">
                                  Lorem ipsum dolor sic
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="text-center">London</td>
                        <td className="text-center">
                          <div className="badge badge-danger text-dark">In Progress</div>
                        </td>
                        <td className="text-center">
                          <button
                            type="button"
                            id="PopoverCustomT-3"
                            className="btn btn-primary btn-sm"
                          >
                            Details
                          </button>
                        </td>
                      </tr>
                      <tr>
                        <td className="text-center text-muted">#55</td>
                        <td>
                          <div className="widget-content p-0">
                            <div className="widget-content-wrapper">
                              <div className="widget-content-left mr-3">
                                <div className="widget-content-left">
                                  <img
                                    width={40}
                                    className="rounded-circle"
                                    src="assets/images/avatars/1.jpg"
                                    alt=""
                                  />
                                </div>
                              </div>
                              <div className="widget-content-left flex2">
                                <div className="widget-heading">
                                  Vinnie Wagstaff
                                </div>
                                <div className="widget-subheading opacity-7">
                                  UI Designer
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="text-center">Amsterdam</td>
                        <td className="text-center">
                          <div className="badge badge-info text-dark">On Hold</div>
                        </td>
                        <td className="text-center">
                          <button
                            type="button"
                            id="PopoverCustomT-4"
                            className="btn btn-primary btn-sm"
                          >
                            Details
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div className="d-block text-center card-footer">
                  
                  <button className="btn-wide btn btn-success">Save</button>
                </div>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-6 col-lg-3">
              <div className="card-shadow-danger mb-3 widget-chart widget-chart2 text-left card">
                <div className="widget-content">
                  <div className="widget-content-outer">
                    <div className="widget-content-wrapper">
                      <div className="widget-content-left pr-2 fsize-1">
                        <div className="widget-numbers mt-0 fsize-3 text-danger">
                          71%
                        </div>
                      </div>
                      <div className="widget-content-right w-100">
                        <div className="progress-bar-xs progress">
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            aria-valuenow={71}
                            aria-valuemin={0}
                            aria-valuemax={100}
                            style={{ width: "71%" }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="widget-content-left fsize-1">
                      <div className="text-muted opacity-6">Income Target</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="card-shadow-success mb-3 widget-chart widget-chart2 text-left card">
                <div className="widget-content">
                  <div className="widget-content-outer">
                    <div className="widget-content-wrapper">
                      <div className="widget-content-left pr-2 fsize-1">
                        <div className="widget-numbers mt-0 fsize-3 text-success">
                          54%
                        </div>
                      </div>
                      <div className="widget-content-right w-100">
                        <div className="progress-bar-xs progress">
                          <div
                            className="progress-bar bg-success"
                            role="progressbar"
                            aria-valuenow={54}
                            aria-valuemin={0}
                            aria-valuemax={100}
                            style={{ width: "54%" }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="widget-content-left fsize-1">
                      <div className="text-muted opacity-6">
                        Expenses Target
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="card-shadow-warning mb-3 widget-chart widget-chart2 text-left card">
                <div className="widget-content">
                  <div className="widget-content-outer">
                    <div className="widget-content-wrapper">
                      <div className="widget-content-left pr-2 fsize-1">
                        <div className="widget-numbers mt-0 fsize-3 text-warning">
                          32%
                        </div>
                      </div>
                      <div className="widget-content-right w-100">
                        <div className="progress-bar-xs progress">
                          <div
                            className="progress-bar bg-warning"
                            role="progressbar"
                            aria-valuenow={32}
                            aria-valuemin={0}
                            aria-valuemax={100}
                            style={{ width: "32%" }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="widget-content-left fsize-1">
                      <div className="text-muted opacity-6">
                        Spendings Target
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6 col-lg-3">
              <div className="card-shadow-info mb-3 widget-chart widget-chart2 text-left card">
                <div className="widget-content">
                  <div className="widget-content-outer">
                    <div className="widget-content-wrapper">
                      <div className="widget-content-left pr-2 fsize-1">
                        <div className="widget-numbers mt-0 fsize-3 text-info">
                          89%
                        </div>
                      </div>
                      <div className="widget-content-right w-100">
                        <div className="progress-bar-xs progress">
                          <div
                            className="progress-bar bg-info"
                            role="progressbar"
                            aria-valuenow={89}
                            aria-valuemin={0}
                            aria-valuemax={100}
                            style={{ width: "89%" }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="widget-content-left fsize-1">
                      <div className="text-muted opacity-6">Totals Target</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
    
        </>
        </Box>
      </Box>

    </div>
  )
}



export default Dashboard
