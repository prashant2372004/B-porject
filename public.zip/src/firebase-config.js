import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBOSUPykCJwHep728NeAQAshCAmNUMAXA0",
  authDomain: "crude-3dcf5.firebaseapp.com",
  databaseURL: "https://crude-3dcf5-default-rtdb.firebaseio.com",
  projectId: "crude-3dcf5",
  storageBucket: "crude-3dcf5.appspot.com",
  messagingSenderId: "49663905998",
  appId: "1:49663905998:web:bde2a65dc0430a6804809f",
  measurementId: "G-ZLV9E1JB64"
};
const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
