import React from 'react'

const Loader = () => {
  return (
    <div>
      <div className="spinner-border text-danger d-flex justify-content-center
       align-items-center text-center" role="status">
        <span className="visually-hidden">Loading...</span>
      </div>
    </div>
  )
}

export default Loader
