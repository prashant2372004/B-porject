import React, { useState } from 'react';

import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';


const Login = () => {

    const [username, setUserName] = useState("")
    const [password, setPassword] = useState("")


    
    const handleUserchange = (e) => {
      setUserName(e.target.value)
    }
    const handlePasswordchange = (e) => {
      setPassword( e.target.value)
    }
    
    const navigate = useNavigate()

    const handleLogin = () => {
      if (username === "admin@software.com" && password === "admin@123") {
        toast.success("Login Successfull")
        navigate('/Attendance')
      }else if(username === "employee@software.com" && password === "employee@123"){
        toast.success("Login Successfull")
        navigate('/Attendance')
      } else{
        toast.error("Please check your input")
      }
    }
    
    return (

        <div className='bsy pt-5'>
            <div className='container-fluid pt-5 '>
                <div className="mb-3 pt-5">
                    <div className="row" style={{ height: '70vh' }}>
                        <div className="col-md-6">
                            <div className='logo'>
                            </div>
                            <img
                                src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcRAYDmaMp--fukdMRGNyjrNdNy4iO-AT4eWqexdPEOTiW1jk3C0"
                                alt="Trendy Pants and Shoes"
                                className="img-fluid  h-75 w-75 ms-5 mt-4"
                            />
                        </div>
                        <div className="col-md-6 mt-5">
                            <div className="card-body">
                                <div className="form-text mb-5 text-center">
                                    <h4 className='text-white'>Welcome to Kuber</h4>
                                    <h6 className='text-white'>Need an account? <a className='text-primary text-decoration-none '>Sign Up</a></h6>
                                </div>
                                <form action="#">
                                    <div className="form-floating mb-3">
                                        <input type="text" className="form-control" placeholder="Enter Your Username" name='username'  onChange={handleUserchange} />
                                        <label htmlFor="floatingInput">Username</label>
                                    </div>
                                    <div className="form-floating">
                                        <input type="password" className="form-control mb-3" placeholder="Enter Your Password" name='password'  onChange={handlePasswordchange} />
                                        <label htmlFor="floatingPassword">Password</label>
                                    </div>
                                    <div className="form-Button text-center">
                                        <button type="button" className="btn btn-primary px-4 py-2"  onClick={handleLogin}>Login</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Login
